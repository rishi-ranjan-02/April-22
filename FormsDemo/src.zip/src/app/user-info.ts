export interface UserInfo {
    userId?:string;
    userName?:string;
    email?:string;
    password?:string;
    role?:number;

}
