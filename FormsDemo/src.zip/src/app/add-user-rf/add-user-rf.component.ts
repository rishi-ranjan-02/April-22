import { Component, EventEmitter, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserInfo } from '../user-info';

@Component({
  selector: 'app-add-user-rf',
  templateUrl: './add-user-rf.component.html',
  styleUrls: ['./add-user-rf.component.css']
})
export class AddUserRFComponent {
  @Output()OnAddNewUser:EventEmitter<UserInfo>
  myFrm:FormGroup = new FormGroup({
    userId:new FormControl('', [Validators.required]),
    userName:new FormControl('', [Validators.required]),
    email:new FormControl('', [Validators.required, Validators.email]),
    password:new FormControl('', [Validators.required]),
    role:new FormControl('', [Validators.required])
    
  });
  constructor()
  {
    this.OnAddNewUser =new EventEmitter<UserInfo>();
  }
  AddNewUser(){
    let userData:UserInfo = {
      userId:this.GetControlValue('userId'),
      userName:this.GetControlValue('userName'),
      email:this.GetControlValue('email'),
      password:this.GetControlValue('password'),
      role:this.GetControlValue('role'),
    }
    console.log(userData)
    this.OnAddNewUser.emit(userData);

  }
GetControlValue(ctrlName:string):any
{
  return this.myFrm.controls[ctrlName].value
}
  

}
