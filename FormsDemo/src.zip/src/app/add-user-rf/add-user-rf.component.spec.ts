import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUserRFComponent } from './add-user-rf.component';

describe('AddUserRFComponent', () => {
  let component: AddUserRFComponent;
  let fixture: ComponentFixture<AddUserRFComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddUserRFComponent]
    });
    fixture = TestBed.createComponent(AddUserRFComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
