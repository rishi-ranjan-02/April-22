import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUserIDComponent } from './add-user-id.component';

describe('AddUserIDComponent', () => {
  let component: AddUserIDComponent;
  let fixture: ComponentFixture<AddUserIDComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddUserIDComponent]
    });
    fixture = TestBed.createComponent(AddUserIDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
