import { Component } from '@angular/core';
import { UserInfo } from '../user-info';
@Component({
  selector: 'app-add-user-id',
  templateUrl: './add-user-id.component.html',
  styleUrls: ['./add-user-id.component.css']
})
export class AddUserIDComponent {
  userData : UserInfo={};
  userId:string=''
  AddNewUser(){
    console.log('Adding New User');
    console.log(this.userData);
    
  }

}
