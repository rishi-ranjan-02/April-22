import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DataSourceService } from '../data-source.service';
import { Router } from '@angular/router';
import { UserInfo } from '../user-info';

@Component({
  selector: 'app-add-restaurant',
  templateUrl: './add-restaurant.component.html',
  styleUrls: ['./add-restaurant.component.css']
})
export class AddRestaurantComponent {
 
  frm:FormGroup=new FormGroup({
    userId:new FormControl(''),
    displayName:new FormControl(''),
    email:new FormControl(''),
    password:new FormControl(''),
    role:new FormControl(''),

  });
  constructor(private srv:DataSourceService, private router:Router)
  {

  }
  ngOnInit():void{
    this.ownerList=this.dsrv.GetAllUsers().filter((r)=>r.role=userType.OWNER);
  }

  OnAddNewRestaurant()
  {
    
  }
  AddNewUser(){
    let userData:UserInfo={
    userId:this.frm.controls['userId'].value,
    displayName:this.frm.controls['displayName'].value,
    email:this.frm.controls['email'].value,
    password:this.frm.controls['password'].value,
    role:this.frm.controls['role'].value,
  };
  console.log(userData);
  this.srv.AddNewUserEntry(userData);
  this.router.navigate(['UserList']);

  } 

}
